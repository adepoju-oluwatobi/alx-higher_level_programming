-- updating the value of Bob's score

UPDATE second_table
SET `score` = 10
WHERE `name` = 'Bob';
