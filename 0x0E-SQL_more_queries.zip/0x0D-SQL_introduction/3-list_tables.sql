-- script that lists all tables

SHOW TABLES;
