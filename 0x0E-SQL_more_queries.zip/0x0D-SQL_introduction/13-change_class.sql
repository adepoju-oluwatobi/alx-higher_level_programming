-- Removing all records of scores <= 5

DELETE FROM second_table
WHERE `score` <= 5;
