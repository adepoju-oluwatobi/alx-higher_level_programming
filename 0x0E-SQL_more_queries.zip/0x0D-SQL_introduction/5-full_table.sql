-- script that prints the full description of first_table

SHOW CREATE TABLE first_table;
