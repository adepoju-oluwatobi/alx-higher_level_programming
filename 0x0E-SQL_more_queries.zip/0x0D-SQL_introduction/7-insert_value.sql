-- insert a new row into first_table

INSERT INTO `first_table` (`id`, `name`) VALUES (89, 'Best School');
