-- script that displays the number of records with id =89

SELECT COUNT(*) FROM first_table WHERE id = 89;
