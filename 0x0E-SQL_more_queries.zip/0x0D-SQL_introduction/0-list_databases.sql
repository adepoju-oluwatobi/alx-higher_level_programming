-- script that lists all databases

SHOW DATABASES;
