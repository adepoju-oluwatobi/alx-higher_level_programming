-- calculating the average score

SELECT AVG(score) as average
FROM second_table;
