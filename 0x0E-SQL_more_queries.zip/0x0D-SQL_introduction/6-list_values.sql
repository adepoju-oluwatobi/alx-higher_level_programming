-- list all rows in first_table

SELECT * FROM first_table;
