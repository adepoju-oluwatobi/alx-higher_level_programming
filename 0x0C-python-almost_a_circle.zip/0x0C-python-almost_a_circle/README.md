# Python programming language ALX SE program
## Almost a circle
