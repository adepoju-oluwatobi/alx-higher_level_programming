Python input and output
