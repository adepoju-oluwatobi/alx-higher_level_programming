Python- Everything is object
